export const environment = {
    production: false,
    // baseUrl: 'http://127.0.0.1:8000/api',
  baseUrl: 'https://fixly-backend-main-b5nlyf.free.laravel.cloud/api',
};
